import React, { useState } from 'react';
import {
  Box,
  Paper,
  TextField,
  Button,
  Typography,
  Container,
  Alert,
  CircularProgress
} from '@mui/material';
import { Send as SendIcon } from '@mui/icons-material';
import axios from 'axios';

const ContactUs = () => {
  const [formData, setFormData] = useState({
    from_name: '',
    reply_to: '',
    subject: '',
    message: ''
  });
  const [status, setStatus] = useState({
    loading: false,
    error: '',
    success: false
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ loading: true, error: '', success: false });

    try {
      const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await axios.post(`${API_URL}/api/contact`, {
        name: formData.from_name,
        email: formData.reply_to,
        subject: formData.subject,
        message: formData.message
      });

      if (response.data.success) {
        setStatus({
          loading: false,
          error: '',
          success: true
        });
        
        // Clear form after successful submission
        setFormData({
          from_name: '',
          reply_to: '',
          subject: '',
          message: ''
        });
      } else {
        throw new Error(response.data.message || 'Failed to send message');
      }
    } catch (err) {
      console.error('Contact form error:', err);
      setStatus({
        loading: false,
        error: err.response?.data?.message || 'Failed to send message. Please try again.',
        success: false
      });
    }
  };

  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Paper sx={{ p: 4 }}>
          <Typography variant="h4" component="h1" gutterBottom align="center">
            Contact Us
          </Typography>
          <Typography variant="body1" gutterBottom align="center" sx={{ mb: 4 }}>
            Have a question or feedback? We'd love to hear from you.
          </Typography>

          {status.error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {status.error}
            </Alert>
          )}

          {status.success && (
            <Alert severity="success" sx={{ mb: 2 }}>
              Your message has been sent successfully!
            </Alert>
          )}

          <Box component="form" onSubmit={handleSubmit}>
            <TextField
              fullWidth
              label="Name"
              name="from_name"
              value={formData.from_name}
              onChange={handleChange}
              margin="normal"
              required
              autoFocus
              sx={{ backgroundColor: '#f8f9fa' }}
            />

            <TextField
              fullWidth
              label="Email"
              name="reply_to"
              type="email"
              value={formData.reply_to}
              onChange={handleChange}
              margin="normal"
              required
              sx={{ backgroundColor: '#f8f9fa' }}
            />

            <TextField
              fullWidth
              label="Subject"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              margin="normal"
              required
              sx={{ backgroundColor: '#f8f9fa' }}
            />

            <TextField
              fullWidth
              label="Message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              margin="normal"
              required
              multiline
              rows={4}
              sx={{ backgroundColor: '#f8f9fa' }}
            />

            <Button
              type="submit"
              fullWidth
              variant="contained"
              size="large"
              disabled={status.loading}
              startIcon={status.loading ? <CircularProgress size={24} /> : <SendIcon />}
              sx={{ mt: 3 }}
            >
              {status.loading ? 'Sending...' : 'Send Message'}
            </Button>
          </Box>
        </Paper>
      </Box>
    </Container>
  );
};

export default ContactUs; 